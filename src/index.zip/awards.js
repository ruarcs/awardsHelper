
module.exports = {
	"best actor": "Eddie Redmayne",
	"best supporting actor": "J. K. Simmons",
    "best actress": "Julianna Moore",
	"best supporting actress": "Patricia Arquette",
};
